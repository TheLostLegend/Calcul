package com.example.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {
    var num1: Float? = null
    var tum:Boolean = true
    lateinit var sttr:String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        button_0.setOnClickListener {
            val str = result_text.text.toString()
            if (str == "0") result_text.text =""
            SetTextFields("0")
        }
        button_1.setOnClickListener {
            val str = result_text.text.toString()
            if (str == "0") result_text.text =""
            SetTextFields("1")
        }
        button_2.setOnClickListener {
            val str = result_text.text.toString()
            if (str == "0") result_text.text =""
            SetTextFields("2")
        }
        button_3.setOnClickListener {
            val str = result_text.text.toString()
            if (str == "0") result_text.text =""
            SetTextFields("3")
        }
        button_4.setOnClickListener {
            val str = result_text.text.toString()
            if (str == "0") result_text.text =""
            SetTextFields("4")
        }
        button_5.setOnClickListener {
            val str = result_text.text.toString()
            if (str == "0") result_text.text =""
            SetTextFields("5")
        }
        button_6.setOnClickListener {
            val str = result_text.text.toString()
            if (str == "0") result_text.text =""
            SetTextFields("6")
        }
        button_7.setOnClickListener {
            val str = result_text.text.toString()
            if (str == "0") result_text.text =""
            SetTextFields("7")
        }
        button_8.setOnClickListener {
            val str = result_text.text.toString()
            if (str == "0") result_text.text =""
            SetTextFields("8")
        }
        button_9.setOnClickListener {
            val str = result_text.text.toString()
            if (str == "0") result_text.text =""
            SetTextFields("9")
        }
        button_Dot.setOnClickListener {
            SetTextFields(".")
        }
///////////////////////////////////////////////////////////////////////////
        button_plus.setOnClickListener {
            SetTextFields2("+")
        }
        button_min.setOnClickListener {
            SetTextFields2("-")
        }
        button_mul.setOnClickListener {
            SetTextFields2("*")
        }
        button_del.setOnClickListener {
            SetTextFields2("/")
        }
        button_mod.setOnClickListener {
            SetTextFields2("%")
        }
//////////////////////////////////////////////////////////////////////////////
        button_del2.setOnClickListener {
            SetTextFields3("1")
        }
        button_mul2.setOnClickListener {
            SetTextFields3("2")
        }
        button_sqrt.setOnClickListener {
            SetTextFields3("3")
        }
        button_change.setOnClickListener {
            SetTextFields3("4")
        }

        button_End.setOnClickListener{

        }


        button_C.setOnClickListener {
            math_operation.text = "0"
            result_text.text = "0"
            num1 = null
            tum = true
        }
        button_CE.setOnClickListener {
            result_text.text = "0"
            tum = true
        }
        button_back.setOnClickListener {
            if (tum){
                val str = result_text.text.toString()
                if(str.isNotEmpty())
                    result_text.text = str.substring(0, str.length - 1)
                if (str.substring(0, str.length - 1)== "")
                    result_text.text = "0"
            }
        }

    }
    fun SetTextFields(str: String){
        if (!tum) result_text.text = ""
        result_text.append(str)
        tum = true
    }
    fun SetTextFields2(str1: String){
        val str = result_text.text.toString()
        val str2 = math_operation.text.toString()
        if (tum){
            val num2:Float
            if (num1 == null) num1 = str.toFloat()
            else {
                num2 = str.toFloat()
                when (sttr){
                    "+" -> num1 = num1!! + num2
                    "-" -> num1 = num1!! - num2
                    "*" -> num1 = num1!! * num2
                    "/" -> num1 = num1!! / num2
                    "%" -> num1 = num1!! % num2
                    else -> result_text.text = "ERROR"
                }
                result_text.text = num1.toString()
            }
            math_operation.text = result_text.text
            tum = false
        }
        else math_operation.text = str2.substring(0, str2.length - 1)
        math_operation.append(str1)
        sttr = str1
    }
    fun SetTextFields3(str1: String){
        val str = result_text.text.toString()
        var num2:Float = str.toFloat()
        when (str1){
            "1" -> num2 = 1/num2
            "2" -> num2 *= num2
            "3" -> num2 = sqrt(num2)
            "4" -> num2 *= -1
            else -> result_text.text = "ERROR"
        }
        result_text.text = num2.toString()
        tum = true
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        math_operation.text = savedInstanceState.getString("math_operation")
        result_text.text = savedInstanceState.getString("result_text")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("math_operation", math_operation.text.toString())
        outState.putString("result_text", result_text.text.toString())
    }
}